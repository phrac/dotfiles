Vim Color Schemes Collection
============================


This Vim color schemes collection is provided by [Chris Kempson](https://github.com/chriskempson) and built with [Base16 builder](https://github.com/chriskempson/base16-builder).


# Installation:

    NeoBundle 'jimzhan/vim-colors'


# Available Themes
    * base16-3024.vim
    * base16-ashes.vim
    * base16-atelierdune.vim
    * base16-atelierforest.vim
    * base16-atelierheath.vim
    * base16-atelierlakeside.vim
    * base16-atelierseaside.vim
    * base16-bespin.vim
    * base16-brewer.vim
    * base16-chalk.vim
    * base16-codeschool.vim
    * base16-default.vim
    * base16-eighties.vim
    * base16-embers.vim
    * base16-google.vim
    * base16-grayscale.vim
    * base16-greenscreen.vim
    * base16-isotope.vim
    * base16-londontube.vim
    * base16-marrakesh.vim
    * base16-mocha.vim
    * base16-monokai.vim
    * base16-ocean.vim
    * base16-paraiso.vim
    * base16-railscasts.vim
    * base16-shapeshifter.vim
    * base16-solarized.vim
    * base16-tomorrow.vim
    * base16-twilight.vim

